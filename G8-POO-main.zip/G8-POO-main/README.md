# 🧠 Proyecto G8-POO - ESPOL

Este es el repositorio oficial del proyecto Java del grupo G8 para la materia de Programación Orientada a Objetos (POO). Aquí trabajaremos de forma colaborativa usando GitHub.
---

## 🛠️ Requisito previo: Instalar Git

Antes de comenzar, asegúrate de tener Git instalado en tu computadora.

### Para Windows:
- Descarga desde [git-scm.com](https://git-scm.com/download/win)
- Instala con las opciones por defecto
- Verifica con: `git --version`

---

## 🚀 ¿Cómo empezar?

### 1. Clonar el proyecto (descargarlo, solo la primera vez)

#### Opción A: Usando VSCode

1. Abre VSCode
2. Abre la terminal (`Ctrl + ñ`)
3. Escribe este comando:

```bash
git clone https://github.com/vigotez/G8-POO.git
```
Esto crea una copia local del proyecto en sus computadoras.
---
📁 ¿Dónde se guarda el proyecto al hacer `git clone`?
Por defecto, Git lo guarda en la carpeta donde estás ubicada en ese momento en la terminal. Pero puedes especificar la ruta y el nombre de la carpeta así:
```bash
git clone https://github.com/usuario/repositorio.git ruta/deseada/nombre-carpeta
```
Ejemplo:
`C:\Users\cato2\OneDrive\ESPOL\2S\POO\Proyecto`

---
[*] Si has clonado el proyecto en una carpeta especifica, **primero** escribe esto en la terminal.
```bash
cd ruta/del/proyecto
```

4. Abre la carpeta clonada:
```bash
cd G8-POO
code .
```

#### Opción B: Usando GitHub Desktop
1. Instala [GitHub Desktop](https://github.com/apps/desktop)

2. Abre el repositorio en GitHub y haz clic en `Code` > `Open with GitHub Desktop`

3. Elige dónde guardar el proyecto y listo

## 🔄 ¿Cómo actualizar el proyecto? (cada vez antes de trabajar)
 
**Antes de hacer cualquier cambio**, siempre **actualiza** tu copia local:
```bash
git pull origin main
```
Esto trae los últimos cambios que hayan hecho tus compañeros.
Esto asegura que están trabajando con la versión más reciente del proyecto.

## ✍️ ¿Cómo hacer cambios, subirlos y guardar los cambios localmente?

1. Realiza tus cambios en el código
2. Guarda los archivos
3. Abre la terminal y escribe:
```bash
git add .
git commit -m "Descripción clara del cambio"
```
## 🚀 Subir los cambios al repositorio
```bash
git push origin main
```
> Ejemplo de mensaje (COMMIT): `"Agregada clase RegistroHidratacion.java"`

## ⚠️ Cosas importantes que NO debes hacer

- ❌ No borres archivos que no creaste
- ❌ No subas carpetas como `target/` (ya está bloqueada con .gitignore)
- ❌ No hagas `git push --force` sin avisar al grupo
- ❌ No trabajes directamente en el código de otro sin coordinar

## 🧼 Buenas prácticas

- ✅ Siempre haz `git pull` antes de empezar
- ✅ Usa mensajes de `commit` claros
- ✅ Si vas a hacer algo grande, crea una rama (preguntar a Dome cómo)
- ✅ Si tienes dudas, pregunta antes de subir

---

## ❗ Importante: No clones el proyecto más de una vez

El comando `git clone` **solo se usa una vez**, al inicio, para descargar el proyecto.

Después de eso:

- Solo abre la carpeta del proyecto en tu computadora
- Usa `git pull` para actualizarlo
- No vuelvas a hacer `git clone`, o crearás copias duplicadas


## 🧰 Estructura del proyecto

```bash
G8-POO/
├── pom.xml
├── src/
│   └── main/
│       └── java/
│           └── com/
│               └── espol/
│                   ├── modelo/
│                   ├── controlador/
│                   └── visualizador/
└── .gitignore
```