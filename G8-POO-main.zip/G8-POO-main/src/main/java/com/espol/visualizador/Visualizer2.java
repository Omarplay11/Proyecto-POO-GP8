package com.espol.visualizador;
import java.util.ArrayList;

import com.espol.modelo.juego.Carta;

public class Visualizer2{
    
    public void mostrarInicio(){
        System.out.println("--- JUEGO DE MEMORIA ECOLÓGICO ---");
        System.out.println("¡Encuentra los 8 pares!");
        System.out.println();
    }

    public void mostrarTabla(ArrayList<Carta> cartas){
        System.out.println("+-----+-----+-----+-----+");
        for (int i = 0; i < cartas.size();i++){
            Carta carta = cartas.get(i);
            String contenido;

            if (carta.isDescubierta() || carta.isEmparejada()){
                contenido = centrarTexto(carta.getContenido(), 5);
            } else {
                contenido = centrarTexto(String.valueOf(i+1),5);
            }

            System.out.print("|" + contenido);

            //Salto de línea cada 4 cartas
            if((i + 1) % 4 == 0){
                System.out.println("|");
                System.out.println("+-----+-----+-----+-----+");
            }
        }
    }

    //Mostrar informacion del juego
    public void mostrarIntentos(int intentos, int paresEncontrados){
        System.out.println("Total de Intentos: " + intentos + " | Pares Encontrados: " + paresEncontrados + "/8");
        System.out.println();
    }

    //Mostrar turno
    public void mostrarInicioTurno(int turno) {
        System.out.println("--- TURNO " + turno + " | SELECCIÓN ---");
    }
    
    //Mostrar linea de ingreso de la primera carta
    public void mostrarSolicitudPrimeraCarta() {
        System.out.print("Ingrese el número de la PRIMERA carta: ");
    }
    
    //Mostrar linea de ingreso de la segunda carta
    public void mostrarSolicitudSegundaCarta() {
        System.out.print("Ingrese el número de la SEGUNDA carta: ");
    }

    //Mostrar linea del voltear carta
    public void mostrarVolteandoCartas(){
        System.out.println();
        System.out.println("Volteando cartas...");
        System.out.println();
    }

    //Mostrar cuando son pares
    public void mostrarParejaEncontrada(String contenido, int carta1, int carta2) {
        System.out.println();
        System.out.println("☑ ¡PAR ENCONTRADO! El par \"" + contenido + "\" (Cartas " + carta1 + " y " + carta2 + ") se mantiene visible.");
    }

    // Mostrar cuando no son pares
    public void mostrarNoEsPareja(String contenido1, String contenido2, int carta1, int carta2) {
        System.out.println();
        System.out.println("✗ ¡ERROR! " + contenido1 + " y " + contenido2 + " no coinciden. Las cartas " + carta1 + " y " + carta2 + " serán cubiertas de nuevo.");
    }

    //Mostrar linea del enter
    public void mostrarPresioneEnter() {
        System.out.print("Presione [ENTER] para continuar  al siguiente intento...");
    }

    //Mostrar cuando el juego termino
    public void mostrarJuegoTerminado(int intentos) {
        System.out.println();
        System.out.println("¡FELICIDADES! HAS GANADO");
        System.out.println("Total de intentos: " + String.format("%-5d", intentos));
        System.out.println();
    }

    //Mostrar cuando la seleccion es invalida
    public void mostrarErrorSeleccionInvalida() {
        System.out.println("Error: Selección inválida. Debe ser un número entre 1 y 16, y la carta no debe estar volteada o emparejada.");
    }

    //Mostrar cuando la selecciones son las mismas cartas
    public void mostrarErrorMismaCarta() {
        System.out.println("Error: No puede seleccionar la misma carta dos veces.");
    }

    //Metodo para centrar texto
    private String centrarTexto(String texto, int ancho) {
        if (texto.length() >= ancho) {
            return texto.substring(0, ancho);
        }
        
        int espacios = ancho - texto.length();
        int izquierda = espacios / 2;
        int derecha = espacios - izquierda;
        
        return " ".repeat(izquierda) + texto + " ".repeat(derecha);
    }
    
    //Metodo para limpiar la pantalla
    public void limpiarPantalla() {
        // Simulación de limpiar pantalla (en consola simple)
        for (int i = 0; i < 50; i++) {
            System.out.println();
        }
    }
}