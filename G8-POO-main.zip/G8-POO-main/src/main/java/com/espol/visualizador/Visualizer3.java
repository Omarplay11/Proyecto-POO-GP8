package com.espol.visualizador;
import com.espol.modelo.hidratacion.RegistroHidratacion;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;



public class Visualizer3 {

    
    public void menuControlHidratacion(){
        System.out.println("\n=== Control de hidratación ===");
        System.out.println("1. Registrar Ingesta de Agua");
        System.out.println("2. Establecer meta diaria");
        System.out.println("3. Ver Progreso Diario y Meta");
        System.out.println("4. Volver al menu");
        System.out.print("Seleccione una opción: ");
    }
    
    public void registrarAgua(){
        System.out.println("\n--- REGISTRAR INGESTA DE AGUA ---");
        
    }

    public void estableMeta(){
        System.out.println("\n--- ESTABLECER META DIARIA DE HIDRATACIÓN---");
    }

    public void progreso(){
        System.out.println("\n---PROGRESO DE HIDRATACION DIARIA---");
    }
    
    public void barrita(int porcentaje, int metaDiaria,int totalHoy){
        if (porcentaje < 0) porcentaje = 0;
        if (porcentaje > 100) porcentaje = 100;

        int ancho = 20; // número de bloques de la barra
        int llenos = (porcentaje * ancho) / 100;

        System.out.print("[");
        for (int i = 0; i < ancho; i++) {
            if (i < llenos) {
                System.out.print("=");
            } else {
                System.out.print("-");
            }
        }
        System.out.println("] " + porcentaje + "% (" + totalHoy + " / " + metaDiaria + " ml)");
    }
    public void mostrarProgresoDiario(LocalDate fecha, int metaDiaria, int totalHoy, int falta, int porcentaje, List<RegistroHidratacion> registrosHoy){                       
        progreso();  

        System.out.println("Fecha: " + fecha + "\n");
        System.out.println("Meta Diaria (ML): " + metaDiaria + " ml");
        System.out.println("Ingesta Acumulada: " + totalHoy + " ml\n");
        System.out.println("Falta: " + falta + " ml");
        barrita(porcentaje, metaDiaria, totalHoy);
        System.out.println();

        System.out.println("Historial de Registros de Hoy:");
        if (registrosHoy.isEmpty()) {
            System.out.println("- No hay registros todavía.");
        } 
         else {
             DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("hh:mm a");
            for (RegistroHidratacion r : registrosHoy) {
                System.out.println("- " + r.getHora().format(formatoHora) +": " + r.getCantidad() + " ml");
            }
        }
        System.out.println("----------------------------------------");
        System.out.println("¡Recuerda mantenerte hidratado!");
        System.out.println("\nPresione [ENTER] para volver al menú de Sostenibilidad...");
    }
      
}

    


