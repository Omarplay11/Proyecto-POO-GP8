package com.espol.visualizador;
import java.util.ArrayList;
import java.util.Scanner;

import com.espol.controlador.Controlador;
import com.espol.modelo.actividad.Actividad;
import com.espol.modelo.actividad.SesionEnfoque;

public class visualizerEnfoque {
    public void  menuTenicaEnfoque(){
        System.out.println("--- T E C N I C A S   D E   E N F O Q U E ---");
        System.out.println("1. Iniciar Pomodoro (25 min Trabajo/ 5 min Descanso)");
        System.out.println("2. Iniciar Deep Work (Sesión Larga de 90 min)");
        System.out.println("3. Volver al Menú Principal");
        System.out.print("Ingrese su opcion: ");
    }

    public void inicioPomodoro(){
        System.out.println("--- INICIAR POMODORO ---");
        System.out.println("Seleccione la Actividad a trabajar:");
        ArrayList<Actividad> listaActividades = Controlador.getListaActividades();
        System.out.printf("%-3s|%-10s|%-20s%n",
                            "ID","TIPO","NOMBRE");
        System.out.println("---|----------|--------------------");
        for(Actividad actividad: listaActividades){
            System.out.printf("%-3d|%-10s|%-20s%n",
            actividad.getId(),actividad.getTipo(),actividad.getNombre());
        }
        System.out.print("Ingrese ID de la actividad (o 0 para salir): ");
    }


        public void inicioDeepwork(){
        System.out.println("--- INICIAR DEEPWORK ---");
        System.out.println("Seleccione la Actividad a trabajar:");
        ArrayList<Actividad> listaActividades = Controlador.getListaActividades();
        System.out.printf("%-3s|%-10s|%-20s%n",
                            "ID","TIPO","NOMBRE");
        System.out.println("---|----------|--------------------");
        for(Actividad actividad: listaActividades){
            System.out.printf("%-3d|%-10s|%-20s%n",
            actividad.getId(),actividad.getTipo(),actividad.getNombre());
        }
        System.out.print("Ingrese ID de la actividad (o 0 para salir): ");
    }

    public void desarrolloPomodoro(Actividad actividad, SesionEnfoque sesionEnfoque){
        System.out.println(">>> INICIANDO TRABAJO EN '"+actividad.getNombre()+"' <<<");
        int ciclo = sesionEnfoque.getCiclos();
        Scanner sc = new Scanner(System.in);
        while(ciclo<=4){
            System.out.println("Técnica: Pomodoro | Ciclo: "+ ciclo+"/4");
            System.out.println("Tiempo de Trabajo: 25:00 minutos restantes");
            System.out.print("[Simulación: el sistema esperaría 25 minutos o la pulsación de ENTER]");
            sc.nextLine();
            System.out.println();
            System.out.println("--- ¡TIEMPO DE TRABAJO TERMINADO!---");
            System.out.println("Sesión registrada.(Avance de la actividad ID "+ actividad.getId() +" actualizado en base al tiempo).");
            System.out.println("Ahora toma un DESCANSO: 5:00 minutos restantes");
            System.out.print("Presione [ENTER] para iniciar el descanso...");
            sc.nextLine();
            ciclo++;
        }

    }

    public void desarrolloDeepwork(Actividad actividad, SesionEnfoque sesionEnfoque){
        Scanner sc = new Scanner(System.in);
        System.out.println(">>> INICIANDO TRABAJO EN '"+actividad.getNombre()+"' <<<");
        System.out.println("Tenica DEEPWORK ");
        System.out.println("Tiempo de trabajo: 90 minutos restantes");
        System.out.print("[Simulación: el sistema esperaría 90 minutos o la pulsación de ENTER]");
        sc.nextLine();
        System.out.println();
        System.out.println("--- ¡TIEMPO DE TRABAJO TERMINADO!---");
        System.out.println("Sesión registrada.(Avance de la actividad ID "+ actividad.getId() +" actualizado en base al tiempo).");
        System.out.print("Presione [ENTER] para regresar al menu");
        sc.nextLine();
    }

    static public void historialSesionTiempo(ArrayList<SesionEnfoque> listaEnfoque){
        System.out.println("--------------------------------");
        System.out.println("HISTORIAL DE GESTION DEL TIEMPO");
        System.out.println("--------------------------------");
        System.out.printf("|%-12s|%-16s|%-12s%n",
                    "Fecha Sesión","Tenica Aplicada","Duración (min)" );
        System.out.println("|------------|----------------|----------------|");
        for (SesionEnfoque sesion: listaEnfoque){
            System.out.printf("|%-12s|%-16s|%-12s%n",
                            sesion.getFechaDeSesion(),sesion.getTipoEnfoque(),sesion.getTiempoEnfoque());
        }
        System.out.println("------------------------------------------------\n");

    }
}
