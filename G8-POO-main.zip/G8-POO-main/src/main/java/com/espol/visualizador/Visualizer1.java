package com.espol.visualizador;
import java.util.ArrayList;
import java.util.Scanner;

import com.espol.controlador.Controlador;
import com.espol.modelo.actividad.Actividad;
import com.espol.modelo.actividad.ActividadAcademica;
import com.espol.modelo.actividad.ActividadPersonal;
import com.espol.modelo.actividad.Prioridad;
import com.espol.modelo.actividad.TipoAcademico;
import com.espol.modelo.actividad.TipoActividad;
import com.espol.modelo.actividad.TipoPersonal;

public class Visualizer1 {
    // MENUS Y VISUALIZADORES PARA LA OPCION 1 
    Scanner sc = new Scanner(System.in);
    public void menu(){
        System.out.println("=== MENU (PLANIFICADOR Y DEMÁS) ===");
        System.out.println("1. Gestión de Actividades");
        System.out.println("2. Técnicas de Enfoque");
        System.out.println("3. Control de hidratación");
        System.out.println("4. Registro diario de Sostenibilidad");
        System.out.println("5. Juego de memoria");
        System.out.println("6. Salir");
        System.out.print("Elija una opcion: ");
    }

    // Menu Gestion de actividades opcion 1.1
    public void menuActividades(){
        System.out.println("1. Visualizar actividades");
        System.out.println("2. Crear actividad");
        System.out.println("3. Registrar avance de actividad");
        System.out.println("4. Eliminar actividad");
        System.out.println("5. Volver al menu");
    }

    // Visualizador de actividades opcion 1.1.1
    public void visualizarActividades(ArrayList<Actividad> listaActividades){
                    System.out.println("--- LISTADO DE ACTIVIDADES PENDIENTES ---\n");
        System.out.println("ID | TIPO         | NOMBRE                       | VENCIMIENTO       | PRIORIDAD | AVANCE |");
        System.out.println("---|--------------|------------------------------|-------------------|-----------|--------|");
        for (Actividad actividad: listaActividades){
        System.out.printf("%-2d | %-12s | %-28s | %-17s | %-9s | %d%%%n",
        actividad.getId(),
        actividad.getTipo(),
        actividad.getNombre(),
        actividad.getFechaLimite(),
        actividad.getPrioridad(),
        actividad.getAvance());
    }
}
    public void finaLineaVisualizadorActividades(){
        System.out.println("-------------------------------------------------------------------------------------------|");
    }
    

    
    // Visualizadores de actividades detallado

    // **Muestra a detalle actividades Personales**
    public void visualizarActividadesDetalladasPersonales(ActividadPersonal actividad){
            System.out.println("=======================================");
            System.out.println("    DETALLES DEL "+ actividad.getTipo()+" (ID "+actividad.getId()+")");
            System.out.println("======================================");
            System.out.println("Nombre: "+ actividad.getNombre());
            System.out.println("Tipo: "+ actividad.getTipo());
            System.out.println("Descripcion: "+ actividad.getDescripcion());
            System.out.println("Prioridad: "+ actividad.getPrioridad());
            double estado = actividad.getAvance();
            String estadoString = Controlador.verificarAvance(estado);
            System.out.println("Estado: "+ estadoString);
            System.out.println("Fecha Límite: "+ actividad.getFechaLimite());
            System.out.println("Tiempo Estimado Total: "+ actividad.getTiempoEstimado()+ " minutos");
            System.out.println("Ubicacion: "+ actividad.getLugar());
            System.out.println("Avance Actual: "+ actividad.getAvance()+"%");

            visualizerEnfoque.historialSesionTiempo(actividad.getHistorialSesiones());
            System.out.print("Presione [ENTER] para regresar a la lista");
    }

    // **Muestra a detalle actividades ACADEMICAS**
    public void visualizarActividadesDetalladasAcademicas(ActividadAcademica actividad){
            System.out.println("=======================================");
            System.out.println("    DETALLES DEL "+ actividad.getTipo() +"(ID "+actividad.getId()+")");
            System.out.println("======================================");
            System.out.println("Nombre: "+ actividad.getNombre());
            System.out.println("Tipo: "+ actividad.getTipo());
            System.out.println("Asignatura: "+ actividad.getAsignatura());
            System.out.println("Descripcion: "+actividad.getDescripcion());
            System.out.println("Prioridad: "+ actividad.getPrioridad());
            double estado = actividad.getAvance();
            String estadoString = Controlador.verificarAvance(estado);
            System.out.println("Estado: "+ estadoString);
            System.out.println("Fecha Límite: "+ actividad.getFechaLimite());
            System.out.println("Tiempo Estimado Total: "+ actividad.getTiempoEstimado()+ " minutos");
            System.out.println("Avance Actual: "+ actividad.getAvance()+"%");
            visualizerEnfoque.historialSesionTiempo(actividad.getHistorialSesiones());
            System.out.print("Presione [ENTER] para regresar a la lista");
    }


    public void mostrarEncabezado() {
    System.out.println("===============================================");
    System.out.println("| C R E A C I O N   DE   A C T I V I D A D E S |");
    System.out.println("===============================================");
    }
    
    public void mostrarPasoCategoria() {
        System.out.println("--- PASO 1: CATEGORÍA ---");
        System.out.println("Seleccione la categoría de la actividad:");
        System.out.println("1. ACADÉMICA (Tarea, Examen, Proyecto)");
        System.out.println("2. PERSONAL (Citas, Ejercicio, Hobbies)");
        System.out.print("Ingrese opción (1 o 2): ");
    }
    
    public void mostrarPasoPersonal() {
        System.out.println("--- PASO 1: TIPO (Personal) ---");
        System.out.println("Ha seleccionado: PERSONAL");
    }
    
    public void mostrarPasoAcademico() {
        System.out.println("--- PASO 1: TIPO (academica) ---");
        System.out.println("Ha seleccionado: ACADEMICA");
    }
    public void mostrarPasoDetalles() {
        System.out.println("--- PASO 3: DETALLES ---");
    }

    private void pedirTipoAcademica() {
    System.out.println("Seleccione el tipo de actividad académica:");
    TipoAcademico[] tipos = TipoAcademico.values();
    
    for (int i = 0; i < tipos.length; i++) {
    System.out.println((i + 1) + ". " + tipos[i].getNombre());
    }
    System.out.print("Opción (1-3): ");
}
    public void pedirAsignatura(){
        System.out.print("Ingrese la asignatura: ");
    }


    private void pedirTipoPersonal() {
    System.out.println("Seleccione el tipo de actividad personal:");
    TipoPersonal[] tipos = TipoPersonal.values();
    for (int i = 0; i < tipos.length; i++) {
        System.out.println((i + 1) + ". " + tipos[i].getNombre()); 
        }
    System.out.print("Opción (1-3): ");
    }


    // Este metodo muestra la confirmación de la actividad creada
    public void mostrarConfirmacion(Actividad actividad) {
        System.out.println("----------------------------------------");
        System.out.println(actividad.getTipo()+" '"+ actividad.getNombre()+ "' creado con exito.");
        System.out.println("----------------------------------------\n");
        System.out.print("Presione [ENTER] para volver al menú principal...");
        sc.nextLine();
    }

    // Visualizador de avance
public void mostrarAvances(ArrayList<Actividad> actividades){
    System.out.println("--- REGISTRAR AVANCE ---");
    System.out.println("Actividades Pendientes:");
    
    System.out.printf("%-3s|%-10s|%-30s|%-10s%n", 
                      "ID", "TIPO", "NOMBRE", "AVANCE (%)");
    System.out.println("---|----------|------------------------------|------------");

    for (Actividad actividad : actividades){
        System.out.printf("%-3d|%-10s|%-30s|%-10s%n",
                          actividad.getId(),
                          actividad.getTipo(),
                          actividad.getNombre(),
                          String.format("%d%%", actividad.getAvance()));
    }
    System.out.println("---------------------------------------------------------------------");
    System.out.print("Ingrese el ID de la actividad a actualizar (o 0 para salir): ");
}
    // Mensaje de lista vacia 
    public void ListaVacia(){
        System.out.println("** LA LISTA SE ENCUENTRA VACIA **\n");
    }

    public int mostrarDetallesDelAvance(Actividad actividad){
        System.out.println("Ha seleccionado: "+ actividad.getTipo()+ "'"+actividad.getNombre()+"'.");
        System.out.println("Avance actual: "+actividad.getAvance() +"%\n");
        System.out.print("Ingrese el **nuevo porcentaje de avance**(0 - 100): ");
        int nuevoAvance = sc.nextInt();
        sc.nextLine();
        while((nuevoAvance>100) || (nuevoAvance<0)){
            System.out.print("Ingrese un rango de avance valido: ");
            nuevoAvance = sc.nextInt();
            sc.nextLine();
        }
        System.out.print("¿Confirma que el nuevo avance para "+ actividad.getTipo() +" ID "+actividad.getId()+" es "+ nuevoAvance+"%?(S/N): ");
        String confirmacion = sc.nextLine();
        if (confirmacion.toUpperCase().equals("S")){
            System.out.print("Presione [ENTER] para volver al menu de gestión");
            sc.nextLine();
            return nuevoAvance;
        } else {
            return actividad.getAvance();

        }
    }

    public void mostrarActividadesAEliminar(ArrayList<Actividad> listaActividades){
        System.out.println("--- ELIMINAR ACTIVIDAD --");
        System.out.println("Seleccione el ID de la actividad a eliminar:");
        System.out.printf("%-3s|%-10s|%-20s%n",
                            "ID","TIPO","NOMBRE");
        System.out.println("---|----------|--------------------");
        for(Actividad actividad: listaActividades){
            System.out.printf("%-3d|%-10s|%-20s%n",
                          actividad.getId(),actividad.getTipo(),actividad.getNombre());
        }
        System.out.print("Ingrese el ID de la actividad a eliminar (o 0 para cancelar): ");
    }

    public void actividadNoEncontrada(int ID){
        System.out.println("La actividad con el ID "+ ID + " no se encuentra registrada\n");
    }

    public void actividadAcademica(){
        mostrarPasoAcademico();
        mostrarPasoDetalles();
        pedirTipoAcademica();
    }

    public void actividadPersonal(){
        mostrarPasoPersonal();
        mostrarPasoDetalles();
        pedirTipoPersonal();
    }

     public void confirmacionEliminacion(int id,Actividad actividad){
            System.out.println("Usted selecciono la actividad ID "+ actividad.getId() + ": '" + actividad.getNombre() + "' ("+actividad.getTipo()+").\n");
            System.out.print("¿Esta seguro que desea ELIMINAR PERMANENTEMENTE esta actividad? (S/N): ");
        }
    
        
}

