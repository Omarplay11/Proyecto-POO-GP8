package com.espol.visualizador;

import com.espol.modelo.sostenibilidad.AccionSostenible;
import java.util.List;

public class Visualizer4 {

    // Menu principal de sostenibilidad
    public void menuSostenibilidad() {
        System.out.println("============================================");
        System.out.println("         REGISTRO DE SOSTENIBILIDAD       ");
        System.out.println("============================================");
        System.out.println("1. Registrar nueva accion sostenible");
        System.out.println("2. Mostrar estadisticas de sostenibilidad");
        System.out.println("3. Volver al menu principal");
        System.out.println("============================================");
    }

    // Confirmacion de registro de accion sostenible
    public void mostrarConfirmacion(AccionSostenible accion) {
        System.out.println("============================================");
        System.out.println("  Accion sostenible registrada con exito");
        System.out.println("--------------------------------------------");
        System.out.println("Accion: " + accion.getAccion());
        System.out.println("Puntos de sostenibilidad: " + accion.getPuntosSostenibilidad());
        System.out.println("Veces realizada: " + accion.getVecesRealizada());
        System.out.println("Logro: " + accion.getLogro());
        System.out.println("============================================");
    }

    // Mostrar todas las acciones registradas
    public void mostrarAcciones(List<AccionSostenible> acciones) {
        System.out.println("============================================");
        System.out.println("  ACCIONES SOSTENIBLES REGISTRADAS:");
        if (acciones.isEmpty()) {
            System.out.println("No hay acciones registradas aun.");
        } else {
            for (AccionSostenible accion : acciones) {
                System.out.println("- Accion: " + accion.getAccion() +
                                   " | Puntos: " + accion.getPuntosSostenibilidad() +
                                   " | Veces: " + accion.getVecesRealizada() +
                                   " | Logro: " + accion.getLogro());
            }
        }
        System.out.println("============================================");
    }

    // Mostrar estadisticas
    public void mostrarEstadisticas(int totalAcciones, int totalPuntos) {
        System.out.println("============================================");
        System.out.println("   ESTADISTICAS DE SOSTENIBILIDAD:");
        System.out.println("Total de acciones realizadas: " + totalAcciones);
        System.out.println("Total de puntos acumulados: " + totalPuntos);
        System.out.println("============================================");
    }
}

