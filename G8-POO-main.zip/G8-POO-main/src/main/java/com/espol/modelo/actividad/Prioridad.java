package com.espol.modelo.actividad;

public enum Prioridad {
    ALTA,
    MEDIA,
    BAJA
}