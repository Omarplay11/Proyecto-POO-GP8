package com.espol.modelo.actividad;

public enum TipoActividad {
    ACADEMICA,
    PERSONAL
}
