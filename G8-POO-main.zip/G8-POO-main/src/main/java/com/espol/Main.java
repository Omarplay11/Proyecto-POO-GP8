package com.espol;

import com.espol.controlador.Controlador;

public class Main {
    public static void main(String[] args) {
        
        Controlador controlador = new Controlador();
        controlador.iniciarApp();
    }
}